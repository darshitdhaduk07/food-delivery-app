package food_delivery_app.payment;

public class CashPayment implements PaymentStrategy {

    @Override
    public boolean pay(double amount) {
        System.out.println("Paid via Cash: ₹" + amount);
        return true;
    }
}
